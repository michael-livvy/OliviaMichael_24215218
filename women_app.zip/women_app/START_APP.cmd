@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if not errorlevel 1 (
    node server.mjs
    goto finished
)
set "WOMEN_APP_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if exist "%WOMEN_APP_NODE%" (
    "%WOMEN_APP_NODE%" server.mjs
) else (
    echo Install Node.js 22.13 or newer, then run this launcher again.
)
:finished
pause
