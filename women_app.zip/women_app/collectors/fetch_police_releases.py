"""Read the canonical public Delhi Police table with normal TLS validation.
Publication metadata are not geolocated crime occurrences.
"""
from html.parser import HTMLParser
from urllib.request import urlopen,Request
from urllib.parse import urljoin,quote
from datetime import datetime,timezone
from pathlib import Path
import json
URL='https://delhipolice.gov.in/press-releases.html'
class Table(HTMLParser):
    def __init__(self):super().__init__();self.row=None;self.cell=None;self.link=None;self.rows=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='tr':self.row=[];self.link=None
        if tag=='td' and self.row is not None:self.cell=[]
        if tag=='a' and self.row is not None and '.pdf' in a.get('href','').lower():self.link=urljoin(URL,a['href'])
    def handle_data(self,s):
        if self.cell is not None:self.cell.append(s)
    def handle_endtag(self,tag):
        if tag=='td' and self.cell is not None:self.row.append(' '.join(''.join(self.cell).split()));self.cell=None
        if tag=='tr' and self.row is not None:
            if len(self.row)==7 and self.link:self.rows.append((self.row,self.link))
            self.row=None
with urlopen(Request(URL,headers={'User-Agent':'DelhiRouteLab educational research'}),timeout=40) as r:text=r.read().decode('utf-8')
p=Table();p.feed(text);records=[]
for row,link in p.rows:
    if row[4].lower()=='press release':continue
    records.append({'id':link.rsplit('/',1)[-1].split('_')[0],'district':row[2],'investigating_station':row[3],
     'category':row[4],'published_at':datetime.strptime(row[5],'%d %b, %Y').date().isoformat(),
     'source_url':quote(link,safe=':/%'),'record_type':'official_press_release_metadata',
     'incident_location':None,'note':'District and investigating station are source metadata, not confirmed incident coordinates.'})
out={'source_url':URL,'fetched_at':datetime.now(timezone.utc).isoformat(),'records':records,
 'coverage':'Only the entries currently exposed in the public table; not a complete crime-occurrence dataset.'}
Path('data/police_releases.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({'records':len(records),'dates':sorted({r['published_at'] for r in records})}))
