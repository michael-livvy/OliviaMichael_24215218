"""Inspect an authorized DMRC GTFS zip and export consecutive scheduled rail arcs.

This is an OFFLINE import/inspection tool, not a timetable-aware routing engine.
The application deliberately does not silently replace its bounded demo network.
"""
import argparse,csv,io,json,zipfile,hashlib
from pathlib import Path
from datetime import datetime,timezone

def gtfs_seconds(value):
    h,m,s=map(int,value.split(':')); return 3600*h+60*m+s

def main():
    p=argparse.ArgumentParser(); p.add_argument('zip');p.add_argument('--output',default='data/dmrc_import.json');args=p.parse_args()
    with zipfile.ZipFile(args.zip) as z:
        members={Path(name).name:name for name in z.namelist() if not name.endswith('/')}
        def read(name,optional=False):
            if name not in members:
                if optional:return []
                raise ValueError('Missing '+name)
            with z.open(members[name]) as f:return list(csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig')))
        stops=read('stops.txt'); routes=read('routes.txt'); trips=read('trips.txt'); times=read('stop_times.txt')
        calendar=read('calendar.txt',True); exceptions=read('calendar_dates.txt',True)
        frequencies=read('frequencies.txt',True); transfers=read('transfers.txt',True)
    trips_by_id={r['trip_id']:r for r in trips}; grouped={}
    for row in times:grouped.setdefault(row['trip_id'],[]).append(row)
    arcs={}
    for trip_id,rows in grouped.items():
        if trip_id not in trips_by_id:continue
        rows.sort(key=lambda r:int(r['stop_sequence']))
        route_id=trips_by_id[trip_id]['route_id']
        for a,b in zip(rows,rows[1:]):
            if not a.get('departure_time') or not b.get('arrival_time'):continue
            duration=gtfs_seconds(b['arrival_time'])-gtfs_seconds(a['departure_time'])
            if duration<0:continue
            key=(a['stop_id'],b['stop_id'],route_id)
            arcs.setdefault(key,[]).append(duration)
    import statistics
    out={'source':'User supplied authorized DMRC GTFS','imported_at':datetime.now(timezone.utc).isoformat(),
         'archive_sha256':hashlib.sha256(Path(args.zip).read_bytes()).hexdigest(),
         'stops':stops,'routes':routes,'calendar':calendar,'calendar_dates':exceptions,'frequencies':frequencies,'transfers':transfers,
         'scheduled_arcs':[dict(zip(['from_stop','to_stop','route_id'],key),median_seconds=statistics.median(ds),sample_count=len(ds)) for key,ds in arcs.items()],
         'limitations':['Schedules are not live train arrivals.','Calendar, frequency, trip selection, station entrances and transfer semantics must be applied before production routing.','Does not activate imported data in the demo app.']}
    path=Path(args.output);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({'stops':len(stops),'routes':len(routes),'scheduled_arcs':len(arcs),'output':str(path)}))
if __name__=='__main__':main()
