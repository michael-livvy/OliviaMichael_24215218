"""Create a source-linked offline locality index from an authorized OSM PBF.
No external geocoding service receives incident or user coordinates.
"""
import argparse,sys,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('pbf');p.add_argument('--module-path');a=p.parse_args()
if a.module_path:sys.path.insert(0,a.module_path)
import osmium
class Places(osmium.SimpleHandler):
    def __init__(self):super().__init__();self.items=[]
    def node(self,n):
        if n.tags.get('place') and n.tags.get('name') and n.location.valid():self.items.append({'id':f'node/{n.id}','name':n.tags.get('name:en',n.tags.get('name')),'lat':n.lat,'lon':n.lon,'kind':n.tags.get('place')})
    def way(self,w):
        name=w.tags.get('name:en',w.tags.get('name'));kind=w.tags.get('place') or ('street' if w.tags.get('highway') else None)
        if not name or not kind:return
        coords=[(n.lat,n.lon) for n in w.nodes if n.location.valid()]
        if not coords:return
        self.items.append({'id':f'way/{w.id}','name':name,'lat':sum(x[0] for x in coords)/len(coords),'lon':sum(x[1] for x in coords)/len(coords),'kind':kind})
h=Places();h.apply_file(a.pbf,locations=True)
Path('data/place_index.json').write_text(json.dumps(h.items,ensure_ascii=False),encoding='utf-8');print(json.dumps({'public_place_and_street_records':len(h.items)}))
