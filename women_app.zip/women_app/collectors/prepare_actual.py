"""Normalize actual map observations. No imputation or synthetic scores."""
from pathlib import Path
import json,collections,csv
source=json.loads(Path('data/delhi_actual.json').read_text(encoding='utf-8'))
features=[];counts=collections.Counter()
for e in source['payload']['elements']:
    tags=e.get('tags',{});point=e if 'lat' in e else e.get('center',{})
    if 'lat' not in point:continue
    kind=('station' if tags.get('railway')=='station' else
          'police' if tags.get('amenity')=='police' else
          'hospital' if tags.get('amenity')=='hospital' else 'lighting_tag')
    counts[kind]+=1
    features.append({'id':f"{e['type']}/{e['id']}",'type':kind,'name':tags.get('name:en',tags.get('name',kind.replace('_',' ').title())),
     'lat':point['lat'],'lon':point['lon'],'osm_edited_at':e.get('timestamp'),
     'lit':tags.get('lit'),'network':tags.get('network'),'operator':tags.get('operator'),
     'station_type':tags.get('station'),'subway':tags.get('subway'),'ref':tags.get('ref'),
     'website':f"https://www.openstreetmap.org/{e['type']}/{e['id']}",
     'note':'A map tag records an observation, not current operational status.'})
out={'data_origin':'actual_openstreetmap','area':'NCT Delhi administrative area ISO3166-2 IN-DL',
     'fetched_at':source['fetched_at'],'osm_base_timestamp':source['payload'].get('osm3s',{}).get('timestamp_osm_base'),
     'source':'https://overpass.private.coffee/api/interpreter','query':source['query'],
     'attribution':'© OpenStreetMap contributors','license':'ODbL 1.0','counts':dict(counts),'features':features,
     'risk_status':'unknown','metro_lines':[],
     'limitations':['OSM tags are incomplete and may be out of date.','The extract covers the Delhi administrative area; feature completeness is not guaranteed.','Lighting-tag way centers do not describe the full extent or current operation of lights.','No crime-risk labels or imputed scores are present.']}
Path('data/actual_features.json').write_text(json.dumps(out,ensure_ascii=False),encoding='utf-8')
with Path('data/actual_features.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(features[0]));w.writeheader();w.writerows(features)
print(json.dumps({'count':len(features),'types':dict(counts),'fetched_at':out['fetched_at']}))
