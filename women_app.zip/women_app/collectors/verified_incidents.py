"""Validate an authorized feed file and export active verified aggregate incidents.

Offline connector boundary, not connected to a police feed or the current route comparison.
Never marks a user report verified. Obtain the file from a trusted moderation service.
python collectors/verified_incidents.py path/to/authorized.json --source-id city_partner
"""
import argparse,json,math
from pathlib import Path
from datetime import datetime,timezone

def active_records(records,source_id,now):
    if not isinstance(records,list):raise ValueError('Expected a JSON array')
    allowed={'obstruction','lighting_outage','service_disruption','official_incident'}
    output=[];seen=set()
    for r in records:
        # Drop pending, disputed, expired or revoked reports from routing influence.
        if r.get('status')!='verified' or r.get('source_id')!=source_id:continue
        event_id=r['event_id']
        if not isinstance(event_id,str) or not event_id or len(event_id)>120:raise ValueError('Invalid event ID')
        if event_id in seen:continue
        observed=datetime.fromisoformat(r['observed_at']);verified=datetime.fromisoformat(r['verified_at']);expires=datetime.fromisoformat(r['expires_at'])
        if any(d.tzinfo is None for d in [observed,verified,expires]):raise ValueError('Timezone offsets are required')
        if not(observed<=verified<=now<expires):continue
        if r['category'] not in allowed:raise ValueError('Unsupported category')
        lat,lon=float(r['lat']),float(r['lon']);severity=float(r['severity'])
        radius=float(r.get('uncertainty_radius_m',500))
        if not all(math.isfinite(x) for x in [lat,lon,severity,radius]):raise ValueError('Invalid numeric value')
        if not (28.3<=lat<=28.95 and 76.8<=lon<=77.6 and 0<=severity<=1 and 100<=radius<=5000):raise ValueError('Outside pilot bounds or invalid severity/precision')
        # Coarsen public positions. No free text, personal IDs, victim or suspect details are exported.
        output.append({'event_id':event_id,'source_id':source_id,'category':r['category'],
         'lat':round(lat,2),'lon':round(lon,2),'uncertainty_radius_m':max(1000,radius),
         'observed_at':observed.isoformat(),'verified_at':verified.isoformat(),'expires_at':expires.isoformat(),
         'severity':severity,'status':'verified','verification_method':r.get('verification_method','partner_moderation')})
        seen.add(event_id)
    return output

def main():
    p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('--source-id',required=True);p.add_argument('--output',default='data/active_verified_incidents.json');args=p.parse_args()
    rows=json.loads(Path(args.input).read_text(encoding='utf-8-sig'))
    now=datetime.now(timezone.utc);out=active_records(rows,args.source_id,now)
    path=Path(args.output);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps({'source_id':args.source_id,'fetched_at':now.isoformat(),'records':out,'note':'Only trusted partner input may be used; this utility cannot authenticate an arbitrary file.'},indent=2),encoding='utf-8')
    print(json.dumps({'active_verified':len(out),'output':str(path)}))
if __name__=='__main__':main()
