"""Small alternative OSM XML snapshot when Overpass is unavailable.
This fetches raw map objects; joining them into a pedestrian graph is separate.
"""
import urllib.request,json,argparse
from pathlib import Path
from datetime import datetime,timezone
import xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--bbox',default='77.210,28.625,77.225,28.638');p.add_argument('--output',default='data/osm_small_delhi');args=p.parse_args()
west,south,east,north=map(float,args.bbox.split(','))
if not (-180<=west<east<=180 and -90<=south<north<=90) or (east-west)*(north-south)>.003:raise ValueError('Choose a small west,south,east,north bbox under .003 square degrees')
url='https://api.openstreetmap.org/api/0.6/map?bbox='+args.bbox
request=urllib.request.Request(url,headers={'User-Agent':'DelhiRouteLab/0.1 small educational map snapshot'})
with urllib.request.urlopen(request,timeout=45) as r:content=r.read()
root=ET.fromstring(content)
prefix=Path(args.output);prefix.parent.mkdir(parents=True,exist_ok=True)
prefix.with_suffix('.osm').write_bytes(content)
meta={'source_url':url,'fetched_at':datetime.now(timezone.utc).isoformat(),'data_origin':'OpenStreetMap',
      'license':'ODbL 1.0','attribution':'© OpenStreetMap contributors',
      'counts':{k:len(root.findall(k)) for k in ['node','way','relation']},
      'note':'Not active in the demo. Edit timestamps do not establish current lighting, opening hours, or safety.'}
prefix.with_suffix('.json').write_text(json.dumps(meta,indent=2),encoding='utf-8');print(json.dumps(meta))
