"""Extract actual metro-track geometry from a source-attributed OSM PBF.
Requires optional dependency: pip install osmium
python collectors/prepare_metro_pbf.py PATH_TO_PBF
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,sys,hashlib
p=argparse.ArgumentParser();p.add_argument('pbf');p.add_argument('--module-path');args=p.parse_args()
if args.module_path:sys.path.insert(0,args.module_path)
import osmium
class Metro(osmium.SimpleHandler):
    def __init__(self):super().__init__();self.ways={};self.relations=[]
    def way(self,w):
        if w.tags.get('railway')!='subway':return
        coords=[[round(n.lat,7),round(n.lon,7)] for n in w.nodes if n.location.valid()]
        if len(coords)>1:self.ways[w.id]={'geometry':coords,'name':w.tags.get('name','Mapped metro track')}
    def relation(self,r):
        if r.tags.get('route')!='subway':return
        self.relations.append({'id':r.id,'name':r.tags.get('name:en',r.tags.get('name','Mapped metro route')),
         'color':r.tags.get('colour','#537fa6'),'ref':r.tags.get('ref'),
         'way_ids':[m.ref for m in r.members if m.type=='w']})
h=Metro();h.apply_file(args.pbf,locations=True)
lines=[];used=set()
for r in h.relations:
    way_ids=[i for i in r.pop('way_ids') if i in h.ways]
    if not way_ids:continue
    r['geometry']=[h.ways[i]['geometry'] for i in way_ids];r['source_url']=f"https://www.openstreetmap.org/relation/{r['id']}"
    lines.append(r);used.update(way_ids)
# Retain actual track ways even when a route relation is absent.
remaining=[(key,w) for key,w in h.ways.items() if key not in used]
if remaining:lines.append({'id':'other-mapped-tracks','name':'Other mapped metro track segments','color':'#537fa6',
 'geometry':[w['geometry'] for key,w in remaining],'osm_way_ids':[key for key,w in remaining],
 'source_url':'https://download.bbbike.org/osm/bbbike/NewDelhi/'})
path=Path('data/actual_features.json');data=json.loads(path.read_text(encoding='utf-8'));data['metro_lines']=lines
data['metro_geometry_provenance']={'source':'https://download.bbbike.org/osm/bbbike/NewDelhi/NewDelhi.osm.pbf','source_publication_utc':'2026-10-24T16:22:26Z','processed_at':datetime.now(timezone.utc).isoformat(),
 'source_sha256':hashlib.sha256(Path(args.pbf).read_bytes()).hexdigest(),'bounding_box':{'south':28.44,'west':76.978,'north':28.738,'east':77.497},
 'note':'Regional extract rectangle does not cover every part of NCT Delhi. Tracks are actual mapped subway ways; current operation and complete network coverage are not independently verified.'}
path.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'actual_track_ways':len(h.ways),'route_groups':len(lines),'route_relations':len(h.relations)}))
