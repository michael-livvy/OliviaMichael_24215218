from urllib.request import urlopen,Request
from urllib.parse import urlencode
from datetime import datetime,timezone
from pathlib import Path
import json
q='''[out:json][timeout:60];way["railway"="subway"](28.35,76.8,28.95,77.55);out tags geom;'''
u='https://overpass.private.coffee/api/interpreter?'+urlencode({'data':q})
with urlopen(Request(u,headers={'User-Agent':'DelhiRouteLab/1.0 educational research'}),timeout=110) as r:raw=json.load(r)
if raw.get('remark'):raise RuntimeError(raw['remark'])
lines=[]
for e in raw.get('elements',[]):
    tags=e.get('tags',{});geometries=[]
    if e.get('geometry'):geometries.append([[p['lat'],p['lon']] for p in e['geometry'] if p is not None])
    for m in e.get('members',[]):
        g=m.get('geometry',[])
        if len(g)>1:geometries.append([[p['lat'],p['lon']] for p in g if p is not None])
    if geometries:lines.append({'id':e['id'],'name':tags.get('name:en',tags.get('name','Metro route')),'color':tags.get('colour','#597eaa'),
     'ref':tags.get('ref'),'geometry':geometries,'source_url':f"https://www.openstreetmap.org/{e['type']}/{e['id']}"})
path=Path('data/actual_features.json');data=json.loads(path.read_text(encoding='utf-8'));data['metro_lines']=lines;data['metro_fetched_at']=datetime.now(timezone.utc).isoformat()
path.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8');Path('data/metro_raw.json').write_text(json.dumps(raw),encoding='utf-8')
print(json.dumps({'route_relations':len(lines),'segments':sum(len(x['geometry']) for x in lines)}))
