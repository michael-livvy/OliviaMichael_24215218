"""Bounded actual OSM observations across NCT Delhi; no synthetic values."""
from urllib.request import urlopen,Request
from urllib.parse import urlencode
from urllib.error import HTTPError
from pathlib import Path
from datetime import datetime,timezone
import json
q='''[out:json][timeout:90];area["ISO3166-2"="IN-DL"]->.d;
(nwr[railway=station](area.d);nwr[amenity=police](area.d);nwr[amenity=hospital](area.d);way[lit](area.d););
out center meta;'''
u='https://overpass.private.coffee/api/interpreter?'+urlencode({'data':q})
try:
    with urlopen(Request(u,headers={'User-Agent':'DelhiRouteLab/1.0 educational research'}),timeout=110) as r:data=json.load(r)
except HTTPError as e:
    print(e.code,e.read(1500).decode(errors='replace'));raise
if data.get('remark'):raise RuntimeError(data['remark'])
if not data.get('elements'):raise ValueError('No records returned; do not interpret as zero facilities')
p=Path('data/delhi_actual.json');p.write_text(json.dumps({'fetched_at':datetime.now(timezone.utc).isoformat(),'source':u,'query':q,'payload':data}),encoding='utf-8');print(json.dumps({'elements':len(data['elements']),'file':str(p)}))
