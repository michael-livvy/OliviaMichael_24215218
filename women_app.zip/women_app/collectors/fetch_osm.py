"""Download a bounded, timestamped OSM snapshot. No safety labels are inferred.
python collectors/fetch_osm.py --bbox 28.620,77.200,28.640,77.230
"""
import argparse, json, urllib.request, urllib.parse
from datetime import datetime, timezone
from pathlib import Path

p=argparse.ArgumentParser(); p.add_argument('--bbox',default='28.620,77.200,28.640,77.230')
p.add_argument('--output',default='data/osm_connaught_place.json')
p.add_argument('--endpoint',default='https://overpass-api.de/api/interpreter'); args=p.parse_args()
box=[float(x) for x in args.bbox.split(',')]
if len(box)!=4 or not (-90<=box[0]<box[2]<=90 and -180<=box[1]<box[3]<=180): raise ValueError('Use south,west,north,east')
if (box[2]-box[0])*(box[3]-box[1])>.01: raise ValueError('Use a small pilot area below 0.01 square degrees; use regional extracts for larger areas.')
b=','.join(map(str,box))
query=f'''[out:json][timeout:90];(
 way[highway][highway!~"motorway|motorway_link"]({b});
 nwr[highway=street_lamp]({b}); nwr[shop]({b});
 nwr[amenity~"restaurant|cafe|pharmacy|hospital|police"]({b});
 nwr[railway=station]({b}); nwr[public_transport=platform]({b});
);out meta geom;'''
endpoint=args.endpoint
if not endpoint.startswith('https://'):raise ValueError('Use an HTTPS Overpass endpoint')
request=urllib.request.Request(endpoint+'?'+urllib.parse.urlencode({'data':query}),
                               headers={'User-Agent':'DelhiRouteLab/0.1 educational bounded data collection'})
with urllib.request.urlopen(request,timeout=120) as response: payload=json.load(response)
if payload.get('remark'): raise RuntimeError('Overpass reported partial/error response: '+payload['remark'])
snapshot={'source':endpoint,'query':query,'fetched_at':datetime.now(timezone.utc).isoformat(),
          'data_origin':'OpenStreetMap','license':'ODbL 1.0','attribution':'© OpenStreetMap contributors',
          'note':'Object timestamps record map edits, not field verification of current conditions.',
          'bbox_south_west_north_east':box,'payload':payload}
path=Path(args.output); path.parent.mkdir(parents=True,exist_ok=True)
path.write_text(json.dumps(snapshot,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'file':str(path),'elements':len(payload.get('elements',[])),'fetched_at':snapshot['fetched_at']}))
