"""Train a small deep neural network using NumPy; export portable JSON weights.

Use only independently audited Delhi data.
Run: python ml/train.py --csv data/audits.csv
"""
from pathlib import Path
import argparse, csv, json, math, copy, hashlib
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PHYSICAL = ['lighting', 'open_businesses', 'transit_distance_m', 'footfall',
            'verified_issue_load', 'sidewalk', 'crossing', 'outage_fraction']
TIME = ['hour_sin', 'hour_cos', 'weekend']
FEATURES = PHYSICAL + TIME
LIMITS = [[0,1],[0,30],[0,2000],[0,100],[0,5],[0,1],[0,1],[0,1],[-1,1],[-1,1],[0,1]]
INPUT_NAMES = FEATURES + [name + '_missing' for name in PHYSICAL]
RUBRIC_WEIGHTS = np.array([.35,.20,.20,.15,.10])

def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, allow_nan=False), encoding='utf-8')

def arrays(rows, medians=None, mean=None, scale=None):
    a=np.array([[float(r[n]) if r[n] not in ('',None) else np.nan for n in FEATURES] for r in rows])
    if np.any(np.isinf(a)) or np.any(~np.isfinite(a[:,8:])):
        raise ValueError('Time features must be finite; physical values must be finite or blank.')
    for j,(lo,hi) in enumerate(LIMITS):
        valid = a[:,j][np.isfinite(a[:,j])]
        if np.any((valid<lo)|(valid>hi)):
            raise ValueError(f'{FEATURES[j]} outside [{lo}, {hi}]')
    missing=np.isnan(a[:,:8]).astype(float)
    if medians is None:
        medians=np.nanmedian(a,axis=0)
        if not np.isfinite(medians).all():
            raise ValueError('Every feature needs at least one observed training value.')
    a=np.where(np.isnan(a),medians,a)
    if mean is None:
        mean=a.mean(axis=0); scale=a.std(axis=0); scale[scale<1e-8]=1
    x=np.concatenate([(a-mean)/scale,missing],axis=1)
    y=np.array([float(r['target_score'])/100 for r in rows]).reshape(-1,1)
    if not np.isfinite(y).all() or np.any((y<0)|(y>1)):
        raise ValueError('Targets must be finite scores between 0 and 100.')
    return x,y,medians,mean,scale

def forward(x, layers):
    acts=[x]
    for i,(w,b) in enumerate(layers):
        z=acts[-1]@w+b
        acts.append(np.maximum(z,0) if i<len(layers)-1 else 1/(1+np.exp(-np.clip(z,-40,40))))
    return acts

def metrics(y,p):
    y=y.ravel()*100; p=p.ravel()*100
    return {'mae':round(float(np.mean(abs(y-p))),3),
            'rmse':round(float(np.sqrt(np.mean((y-p)**2))),3),
            'r2':round(float(1-np.sum((y-p)**2)/np.sum((y-y.mean())**2)),4)}

def train(rows, epochs=220):
    if any(r.get('data_origin')!='field_audit' for r in rows):
        raise ValueError('Only real field_audit observations are accepted.')
    partitions={s:[r for r in rows if r['split']==s] for s in ['train','validation','test']}
    if any(len(v)<40 for v in partitions.values()):
        raise ValueError('Provide at least 40 observations in each explicit split.')
    for a,b in [('train','validation'),('train','test'),('validation','test')]:
        if {r['spatial_block'] for r in partitions[a]} & {r['spatial_block'] for r in partitions[b]}:
            raise ValueError('Spatial blocks overlap between splits.')
    for a,b in [('train','validation'),('validation','test')]:
        # ISO-8601 values must have the same UTC offset in an input dataset.
        from datetime import datetime
        if max(datetime.fromisoformat(r['observed_at']) for r in partitions[a]) >= min(datetime.fromisoformat(r['observed_at']) for r in partitions[b]):
            raise ValueError('Splits must be chronological: train before validation before test.')
    x,y,med,mean,scale=arrays(partitions['train'])
    vx,vy,*_=arrays(partitions['validation'],med,mean,scale)
    tx,ty,*_=arrays(partitions['test'],med,mean,scale)
    rng=np.random.default_rng(17)
    dims=[len(INPUT_NAMES),64,32,16,1]
    layers=[(rng.normal(0,np.sqrt(2/a),(a,b)),np.zeros((1,b))) for a,b in zip(dims[:-1],dims[1:])]
    m=[(np.zeros_like(w),np.zeros_like(b)) for w,b in layers]
    v=copy.deepcopy(m); step=0; history=[]; best_loss=float('inf'); best=None; patience=0
    l2=1e-5; learning_rate=.001
    for epoch in range(epochs):
        ids=rng.permutation(len(x))
        for start in range(0,len(x),128):
            batch=ids[start:start+128]; acts=forward(x[batch],layers)
            delta=2*(acts[-1]-y[batch])*acts[-1]*(1-acts[-1])/len(batch)
            grads=[]
            for i in range(len(layers)-1,-1,-1):
                w,b=layers[i]
                grads.append((acts[i].T@delta+l2*w,delta.sum(axis=0,keepdims=True)))
                if i: delta=(delta@w.T)*(acts[i]>0)
            step+=1
            for i,(gw,gb) in enumerate(reversed(grads)):
                for j,g in enumerate((gw,gb)):
                    m[i][j][...] = .9*m[i][j]+.1*g
                    v[i][j][...] = .999*v[i][j]+.001*g*g
                    layers[i][j][...] -= learning_rate*(m[i][j]/(1-.9**step))/(np.sqrt(v[i][j]/(1-.999**step))+1e-8)
        train_loss=float(np.mean((forward(x,layers)[-1]-y)**2))
        val_loss=float(np.mean((forward(vx,layers)[-1]-vy)**2))
        history.append({'epoch':epoch+1,'train_mse':train_loss,'validation_mse':val_loss})
        if val_loss<best_loss-1e-6:
            best_loss=val_loss; best=copy.deepcopy(layers); best_epoch=epoch+1; patience=0
        else: patience+=1
        if patience>=22: break
    layers=best
    # Ridge regression and a train-mean predictor are independent benchmarks.
    xa=np.column_stack([np.ones(len(x)),x]); ta=np.column_stack([np.ones(len(tx)),tx])
    penalty=np.eye(xa.shape[1])*.01; penalty[0,0]=0
    coef=np.linalg.solve(xa.T@xa+penalty,xa.T@y)
    report={'data_origin':sorted({r.get('data_origin','unspecified') for r in rows}),
            'interpretation':'Predicts the defined field audit rubric, not crime probability or guaranteed safety.',
            'split_counts':{s:len(rs) for s,rs in partitions.items()},'unused_rows':sum(r['split']=='unused' for r in rows),
            'split_method':'Disjoint spatial blocks AND strictly later observation periods',
            'best_epoch':best_epoch, 'epochs_run':len(history),'seed':17,
            'architecture':dims,'parameter_count':sum(w.size+b.size for w,b in layers),
            'test':{'mean_baseline':metrics(ty,np.full_like(ty,y.mean())),
                    'ridge_baseline':metrics(ty,np.clip(ta@coef,0,1)),
                    'dnn':metrics(ty,forward(tx,layers)[-1])},'history':history}
    model={'version':'delhi-field-audit-dnn-v1','data_origin':report['data_origin'],'architecture':dims,
           'features':FEATURES,'input_names':INPUT_NAMES,'limits':LIMITS,
           'medians':med.tolist(),'mean':mean.tolist(),'scale':scale.tolist(),
           'layers':[{'weights':w.tolist(),'bias':b.ravel().tolist()} for w,b in layers],
           'best_epoch':best_epoch,'test_metrics':report['test']['dnn']}
    write_json(ROOT/'data/model.json',model); write_json(ROOT/'data/training_report.json',report)
    write_json(ROOT/'data/parity_fixture.json',{'raw':[{n:None if r[n]=='' else float(r[n]) for n in FEATURES} for r in partitions['test'][:12]],
                                             'scores':(forward(tx[:12],layers)[-1].ravel()*100).tolist()})
    digest=hashlib.sha256((ROOT/'data/model.json').read_bytes()).hexdigest()
    write_json(ROOT/'data/model_manifest.json',{'sha256':digest,'version':model['version'],'data_origin':model['data_origin']})
    print(json.dumps({k:v for k,v in report.items() if k!='history'},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--csv',required=True);p.add_argument('--epochs',type=int,default=220)
    args=p.parse_args()
    with open(args.csv,newline='',encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
    train(rows,args.epochs)
