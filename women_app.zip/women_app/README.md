# Delhi Route Lab

A presentation-ready Delhi walking-route explorer with a blush-themed map interface, sourced local reports, route explanations, and a DNN training pipeline.

## Run the app

Double-click **START_APP.cmd**, or run:

```powershell
node server.mjs
```

Open **http://127.0.0.1:8787/**. Keep the terminal open. Node.js 22.13 or newer is required. The local app needs no npm packages or build step. `npm start` also works when Node/npm are installed.

Internet access is needed for OpenStreetMap tiles and Valhalla route calculations. Only the two selected route pins are sent for routing. The presentation screenshot is available in `docs/screenshots/dashboard.png`.

## Project structure

| Location | Purpose |
| --- | --- |
| `public/` | Frontend, blush theme, Leaflet assets and license |
| `src/` | API, actual walking routes and report-overlap comparison |
| `server.mjs` | Lightweight local server |
| `ml/train.py` | DNN training code |
| `data/` | Actual datasets, provenance, CSV exports and audit template |
| `collectors/` | Dataset collection and preparation scripts |
| `tests/` | Backend and evidence-comparison checks |
| `docs/PRESENTATION_GUIDE.md` | Suggested demo and talking points |
| `docs/PROJECT_GUIDE.md` | Detailed ANN architecture, data and evaluation plan |

## Train the DNN

```powershell
python -m pip install -r requirements.txt
python ml/train.py --csv data/audits.csv
```

Collect independently audited real labels using `data/audit_template.csv` before training. The network is **19 → 64 → 32 → 16 → 1** and uses NumPy. The project includes training code; validated Delhi model weights and accuracy results are not yet available. See the project guide for the rubric, features and split requirements.

## Verify the app

```powershell
node --test tests/actual.test.mjs
```

## Data and interpretation

The report snapshot covers **28 May–28 October 2026**, with 29 reviewed reports and 27 mapped references. The app compares approximate report-area overlap and walking time. It does not establish current danger or a calibrated safety rating. Metro overlays show mapped tracks, not live train schedules. Read `data/README.md` for dataset roles and provenance.

The full original development workspace and published site are preserved separately. This folder contains the files needed to run, explain, test and extend the local presentation app.
