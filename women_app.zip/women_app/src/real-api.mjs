import dataset from '../data/actual_features.json' with {type:'json'};
import incidents from '../data/reported_incidents.json' with {type:'json'};
import {route} from './routing.mjs';
import {evaluateRoutes} from './route-evidence.mjs';
import releases from '../data/police_releases.json' with {type:'json'};
const headers={'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff'};
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers});
export async function api(request){
 const url=new URL(request.url);
 if(request.method==='GET'&&url.pathname==='/api/health')return json({status:'ok',mode:'actual_data_only',risk_model:'awaiting_ground_truth'});
 if(request.method==='GET'&&url.pathname==='/api/network')return json({...dataset,served_at:new Date().toISOString(),risk_status:'unknown',live_crime_status:'not_connected'});
 if(request.method==='GET'&&url.pathname==='/api/incidents')return json(incidents);
 if(request.method==='GET'&&url.pathname==='/api/crime-context')return json({window:incidents.window,police_releases:releases});
 if(request.method==='GET'&&url.pathname==='/api/model')return json({status:'not_trained_on_validated_delhi_labels',architecture:[19,64,32,16,1],predictions_enabled:false,reason:'No independently audited street-level Delhi target dataset is connected. No synthetic data or synthetic-trained weights are used.'});
 if(request.method==='POST'&&url.pathname==='/api/routes'){
  try{const text=await request.text();if(text.length>8192)return json({error:'Request too large'},413);
   const body=JSON.parse(text);if(!body||typeof body!=='object'||Array.isArray(body))throw new Error('Expected a JSON object.');
   const result=await route(body);return json({...result,...evaluateRoutes(result.routes,dataset.features,incidents.records,Date.parse(incidents.window.end+'T23:59:59+05:30'))});
  }catch(e){return json({error:e.message??'Route unavailable'},e.name==='TimeoutError'?504:400);}
 }
 if(url.pathname==='/api/predict')return json({error:'Risk predictions are disabled until validated Delhi labels are available.'},503);
 return json({error:'Not found'},404);
}
