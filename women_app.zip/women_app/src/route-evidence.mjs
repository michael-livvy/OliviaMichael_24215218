// Compares observed source coverage, not calibrated personal safety.
const meters=(a,b)=>{const r=Math.PI/180,x=(b[1]-a[1])*r*Math.cos((a[0]+b[0])/2*r),y=(b[0]-a[0])*r;return Math.hypot(x,y)*6371000;};
function segmentDistance(p,a,b){
 const scale=111195,cos=Math.cos(p[0]*Math.PI/180),xy=q=>[(q[1]-p[1])*scale*cos,(q[0]-p[0])*scale];
 const x=xy(a),y=xy(b),dx=y[0]-x[0],dy=y[1]-x[1],den=dx*dx+dy*dy,t=den?Math.max(0,Math.min(1,-(x[0]*dx+x[1]*dy)/den)):0;
 return Math.hypot(x[0]+t*dx,x[1]+t*dy);
}
export function evaluateRoutes(routes,features,incidents,asOf=Date.now()){
 const horizon=new Date(asOf);horizon.setUTCMonth(horizon.getUTCMonth()-5);const start=horizon.toISOString().slice(0,10),end=new Date(asOf).toISOString().slice(0,10);
 const reports=incidents.filter(r=>r.routing_eligible===true&&Number.isFinite(r.lat)&&Number.isFinite(r.lon)&&r.event_date&&r.event_date>=start&&r.event_date<=end);
 const enriched=routes.map(route=>{
  const geometry=route.geometry,matched=reports.filter(r=>geometry.slice(1).some((b,i)=>segmentDistance([r.lat,r.lon],geometry[i],b)<=r.uncertainty_radius_m));
  let overlap=0;const perReport=new Map(matched.map(r=>[r.id,0]));
  for(let i=1;i<geometry.length;i++){
   const a=geometry[i-1],b=geometry[i],length=meters(a,b),n=Math.max(1,Math.ceil(length/50));let hits=0;
   for(let j=0;j<n;j++){const t=(j+.5)/n,p=[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];let inside=false;
    for(const r of matched)if(meters(p,[r.lat,r.lon])<=r.uncertainty_radius_m){inside=true;perReport.set(r.id,perReport.get(r.id)+length/n);}
    if(inside)hits++;
   }
   overlap+=length*hits/n;
  }
  const lights=features.filter(f=>f.type==='lighting_tag'&&geometry.slice(1).some((b,i)=>segmentDistance([f.lat,f.lon],geometry[i],b)<=150));
  return {...route,evidence:{report_count:matched.length,report_ids:matched.map(r=>r.id),report_overlap_m:Math.round(overlap),
   report_areas:matched.map(r=>({id:r.id,overlap_m:Math.round(perReport.get(r.id))})),
   mapped_lit_yes:lights.filter(f=>f.lit==='yes').length,mapped_lit_no:lights.filter(f=>f.lit==='no').length,
   report_window_months:5,lighting_buffer_m:150,coverage:'selected_sources_only',
   limits:'Known occurrence dates only; approximate report areas, not exact crime scenes. Counts do not measure crime rates. Lighting tags do not verify current operation.'}};
 });
 if(!enriched.length)return {routes:[],recommendation:null};
 const fastest=enriched.reduce((a,b)=>a.minutes<=b.minutes?a:b);
 const eligible=enriched.filter(r=>r.minutes<=fastest.minutes*1.5);
 const lower=eligible.reduce((a,b)=>a.evidence.report_overlap_m<b.evidence.report_overlap_m||(a.evidence.report_overlap_m===b.evidence.report_overlap_m&&a.minutes<=b.minutes)?a:b);
 const meaningful=fastest.evidence.report_overlap_m-lower.evidence.report_overlap_m>=100;
 const selected=meaningful?lower:fastest;
 const alternatives=enriched.filter(r=>r.id!==fastest.id);
 const leastOverlapAlternative=alternatives.reduce((a,b)=>!a||b.evidence.report_overlap_m<a.evidence.report_overlap_m?b:a,null);
 const areaNames=ids=>[...new Set(reports.filter(r=>ids.includes(r.id)).map(r=>r.area))].join(', ');
 const extraTime=minutes=>minutes<1?`${Math.round(minutes*60)} sec`:`${Math.round(minutes*10)/10} min`;
 for(const r of enriched){
  const baseline=fastest.evidence,own=r.evidence,reduction=baseline.report_overlap_m-own.report_overlap_m;
  const avoided=baseline.report_ids.filter(id=>!own.report_ids.includes(id)),added=own.report_ids.filter(id=>!baseline.report_ids.includes(id));
  const reduced=baseline.report_areas.flatMap(a=>{const b=own.report_areas.find(x=>x.id===a.id);return b&&a.overlap_m-b.overlap_m>=50?[{id:a.id,baseline_overlap_m:a.overlap_m,route_overlap_m:b.overlap_m,reduction_m:a.overlap_m-b.overlap_m}]:[];});
  const increased=baseline.report_areas.flatMap(a=>{const b=own.report_areas.find(x=>x.id===a.id);return b&&b.overlap_m-a.overlap_m>=50?[{id:a.id,baseline_overlap_m:a.overlap_m,route_overlap_m:b.overlap_m,increase_m:b.overlap_m-a.overlap_m}]:[];});
  const within=r.minutes<=fastest.minutes*1.5,extra=Math.max(0,r.minutes-fastest.minutes);
  let summary;
  if(r.id===fastest.id){
   if(!leastOverlapAlternative)summary='Only one walking route was returned, so a safer alternative cannot be compared.';
   else if(meaningful)summary=`Fastest walk. The suggested alternative has ${fastest.evidence.report_overlap_m-selected.evidence.report_overlap_m} m less overlap with mapped report areas for ${extraTime(selected.minutes-fastest.minutes)} extra walking.`;
   else if(leastOverlapAlternative.evidence.report_overlap_m-baseline.report_overlap_m>=100)summary=`Fastest walk and ${leastOverlapAlternative.evidence.report_overlap_m-baseline.report_overlap_m} m less overlap with mapped report areas than ${alternatives.length===1?'the alternative':'any returned alternative'}. It also saves ${extraTime(leastOverlapAlternative.minutes-fastest.minutes)} walking compared with ${alternatives.length===1?'that alternative':'the next lowest-overlap option'}.`;
   else summary='Fastest walk. The available reports do not show a clear safety advantage for another returned option within the detour limit.';
  }
  else if(reduction>=100)summary=`${reduction} m less overlap with recent mapped report areas than the fastest walk, for ${extraTime(extra)} extra walking.${avoided.length?' Avoids the mapped report areas at '+areaNames(avoided)+'.':''}${added.length?' Also enters mapped report areas at '+areaNames(added)+'.':''}${within?'':' This exceeds the 50% time-detour limit, so it is not suggested.'}`;
  else if(reduction<=-100)summary=`${-reduction} m more overlap with mapped report areas than the fastest walk, with ${extraTime(extra)} extra walking. The current evidence does not favor this option.`;
  else summary=`Similar mapped-report overlap to the fastest walk, with ${extraTime(extra)} extra walking. The current evidence does not establish a safety advantage.`;
  r.comparison={baseline_id:fastest.id,is_fastest:r.id===fastest.id,within_detour_limit:within,
   extra_minutes:Math.round(extra*10)/10,extra_distance_m:Math.round((r.length_m??0)-(fastest.length_m??0)),
   detour_percent:fastest.minutes>0?Math.round(extra/fastest.minutes*100):0,
   overlap_reduction_m:reduction,avoided_report_ids:avoided,added_report_ids:added,reduced_report_areas:reduced,increased_report_areas:increased,summary};
 }
 const reason=selected.comparison.summary;
 return {routes:enriched,recommendation:{id:selected.id,baseline_id:fastest.id,label:meaningful?'Lower mapped-report exposure':'Fastest returned option',reason,
  meaningful_reduction:meaningful,minimum_overlap_reduction_m:100,max_time_detour_percent:50,
  safety_status:'not_validated',note:'This is an evidence comparison, not a prediction that the route is safe.'}};
}
