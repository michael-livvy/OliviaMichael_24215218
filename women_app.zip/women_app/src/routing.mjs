// External routing was explicitly approved by the user in this chat.
// Only the two selected public route pins are sent to the fixed Valhalla endpoint.
const cache=new Map();
export function validatePoint(p){
 if(!p||!Number.isFinite(p.lat)||!Number.isFinite(p.lon))throw new Error('Select a start and destination.');
 if(p.lat<28.35||p.lat>28.95||p.lon<76.75||p.lon>77.55)throw new Error('Choose points within the Delhi region.');
 return {lat:p.lat,lon:p.lon};
}
export function decodePolyline(str){
 let i=0,lat=0,lon=0;const points=[];
 while(i<str.length){
  const read=()=>{let r=0,s=0,b;do{if(i>=str.length||s>30)throw new Error('Invalid route geometry');b=str.charCodeAt(i++)-63;r|=(b&31)<<s;s+=5;}while(b>=32);return r&1?~(r>>1):r>>1;};
  lat+=read();lon+=read();points.push([lat/1e6,lon/1e6]);
 }
 return points;
}
export async function route(body,fetcher=fetch){
 const from=validatePoint(body.from),to=validatePoint(body.to);
 if(Math.abs(from.lat-to.lat)+Math.abs(from.lon-to.lon)<.00005)throw new Error('Choose different points.');
 const key=JSON.stringify([from,to]),saved=cache.get(key);if(saved&&Date.now()-saved.at<600000)return saved.value;
 const payload={locations:[from,to],costing:'pedestrian',units:'kilometers',alternates:1};
 const url='https://valhalla1.openstreetmap.de/route?json='+encodeURIComponent(JSON.stringify(payload));
 const response=await fetcher(url,{headers:{'X-Client-Id':'delhi-route-lab-research'},signal:AbortSignal.timeout(25000)});
 if(!response.ok)throw new Error('Routing provider unavailable. No estimated route has been substituted.');
 const data=await response.json();if(!data.trip)throw new Error(data.error??'No pedestrian route found.');
 const trips=[data.trip,...(data.alternates??[]).map(x=>x.trip)].filter(Boolean);
 const value={generated_at:new Date().toISOString(),source:'Valhalla / OpenStreetMap',mode:'pedestrian',risk_model_status:'awaiting_independent_delhi_labels',routes:trips.map((trip,i)=>({
  id:String(i),label:i?'Alternative walk':'Primary returned walk',minutes:trip.summary.time/60,length_m:trip.summary.length*1000,
  geometry:trip.legs.flatMap(l=>decodePolyline(l.shape)),steps:trip.legs.flatMap(l=>l.maneuvers??[]).map(m=>({instruction:m.instruction,minutes:m.time/60,length_m:m.length*1000})),
  risk:null,score:null,crime_coverage:'incomplete'}))};
 if(cache.size>=200)cache.delete(cache.keys().next().value);cache.set(key,{at:Date.now(),value});return value;
}
