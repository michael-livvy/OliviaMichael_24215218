# Delhi route comparison project guide

Updated on 28 October 2026. This guide describes the implemented actual-data application and the work required to turn it into a validated ANN project with current incident updates and metro journey planning. It does not report invented training results.

## 1 Project definition

The application helps a person compare routes using observed local conditions: mapped lighting, activity, transport access, pedestrian infrastructure and verified reports. A deep neural network can estimate a precisely defined field-audit indicator. A routing engine can then compare travel time and exposure to weaker indicators. The indicator must have a documented target; it cannot be interpreted as a probability that a traveler will be safe.

The geographic interface now covers the whole Delhi region. The actual infrastructure query selects records inside the NCT Delhi administrative area with `ISO3166-2=IN-DL`. Selected map pins support pedestrian routing across the region. Crime data completeness is a separate question: extending the map does not create incident observations for unobserved neighborhoods.

The implemented app uses actual data only. Earlier synthetic data and trained synthetic weights were removed at the user's request. The DNN remains untrained for deployment because independent Delhi labels are missing. Every area currently has unknown risk. This is a substantive data limitation, not a user-interface issue.

## 2 What is implemented

The frontend has an interactive street map, station selectors, map-pin placement, pedestrian route alternatives, a metro geometry layer, optional hospital and police facility layers, lighting-tag observations, report-date filters, linked source popups and an area evidence explanation. Route selection displays evidence near the route midpoint. That midpoint explanation is a local sample, not an evaluation of the complete route.

The dashboard uses a compact journey planner, the street map and a dedicated reason panel. On wide screens, the reason is beside the map; on narrow screens, it appears before the map. A prominent summary and two figures show the difference in report-area overlap and walking time. Source details expand below the main reason. Empty, loading and error states explain what happens next without inventing scores.

The backend exposes:

| Endpoint | Behavior |
| --- | --- |
| `GET /api/health` | Actual-data status and model readiness |
| `GET /api/network` | Actual features, provenance and metro geometries |
| `GET /api/incidents` | 29 reviewed public reports in the five-month window and limitations |
| `GET /api/crime-context` | Recent official police-release metadata; no historical aggregate layer |
| `GET /api/model` | DNN architecture and explicit disabled prediction status |
| `POST /api/routes` | Pedestrian routes from the approved Valhalla provider |
| `/api/predict` | Returns unavailable until validated model activation |

The route backend validates coordinates within a Delhi-region bounding box, uses a fixed provider hostname, caches routes for ten minutes, times out failed requests and returns a visible error instead of inventing a replacement route. Public routing and tile services provide no production service guarantee. Before a broad launch, use a contracted provider or self-host the routing engine and follow the provider's usage policy.

The frontend's area explanation counts actual mapped observations within 700 metres. Lighting values come from way centers, which can be far from the street section under inspection. A nearby hospital or police station is an access observation, not evidence that crime is low. Incident circles use documented locality or road reference points with conservative 900–6,000 metre uncertainty radii, depending on source precision. These are review bounds, not statistical confidence regions or exact crime scenes. Records with uncertainty greater than 2,000 metres are excluded from route comparison.

## 3 Dataset inventory and freshness

| Source | Access and date checked | Suitable use | Important limitation |
| --- | --- | --- | --- |
| Actual OSM NCT Delhi query | Downloaded 27 Oct 2026 | Mapped stations, hospitals, police facilities and lit tags | Incomplete tags; edits do not verify current operation |
| Separate central Delhi OSM XML | Downloaded 27 Oct 2026 | Inspect raw nodes, ways and source coverage | Small geographic subset; not citywide |
| Recent regional OSM extracts | [BBBike NewDelhi](https://download.bbbike.org/osm/bbbike/NewDelhi/) | Metro geometry fallback and offline graph preparation | Published extraction rectangle is not the whole NCT; coverage must remain explicit |
| [Delhi OTD DMRC static data](https://otd.delhi.gov.in/data/staticDMRC/) | Portal lists 10 Aug 2023 | GTFS stations, routes, trips and approximate stop times | Too old to assume the present full network or current timetable |
| [Delhi Transport Stack DMRC catalog](https://delhi.transportstack.in/data-services/datadetails/2) | Catalog describes manual updates; listed 2024 metadata | Another official discovery point for current files | Confirm actual archive publication date and license before use |
| [OTD real-time documentation](https://otd.delhi.gov.in/documentation/) | Checked 27 Oct 2026 | Authorized bus vehicle-position ingestion | A key is required; this is not proof of a public DMRC live-arrivals API |
| [Delhi Police press releases](https://delhipolice.gov.in/press-releases.html) | October 2026 entries visible during research | Dated official statements requiring individual review | Listing district/station is not necessarily the incident location; not a complete occurrence feed |
| 29 linked public media reports | Reviewed through 28 Oct 2026; 28 May–28 Oct window | Source-linked locality references and report-overlap comparison | Selected, incomplete, potentially delayed, not independently verified |
| New local field audits | Must be collected | Independent supervised indicator targets | Time and geographic sampling are the main project work |

The actual NCT query returned 270 station records, 646 hospital records, 188 police facility records and 1,037 lighting-tag way-center observations. These are counts of map objects. Deduplicate objects before estimating numbers of physical facilities. The raw JSON retains the upstream OSM base timestamp and the exact query.

The geometry supplement contains 1,389 actual subway track ways, grouped into 32 mapped route-relation overlays plus one group for remaining track segments. It was extracted from BBBike's regional PBF published 24 October 2026. Its rectangle is 28.44–28.738 N and 76.978–77.497 E, so it does not cover every NCT margin. The citywide station/facility query and the regional geometry layer have different geographic coverage; the map does not imply complete metro geometry or current service.

The separate small central Delhi XML contained 1,273 objects with a highway tag but only 16 objects with a lit tag. This example demonstrates the missing-data problem; those tag counts are not a measure of lighting coverage or numbers of streets.

For every production source, retain `source_id`, source URL, license, geographic coverage, upstream version, publication time, observed time, fetched time, expiry and validation outcome. A current fetch of a 2023 archive does not make its observations current.

[NASA VNP46A2](https://ladsweb.modaps.eosdis.nasa.gov/missions-and-measurements/products/VNP46A2/) can provide daily nighttime-light context on an approximately 500-metre grid. It cannot resolve individual working street lamps. It is optional neighborhood context and is not currently connected. Never convert its brightness into verified sidewalk lighting.

## 4 Actual crime data and known locations

The application treats known locations as reported incident locations. It stores no criminal profiles, personal addresses, victim identifiers or suspect tracking. The 29 reports are in `data/reported_incidents.json` and `.csv`; original publication links are displayed in the app. Twenty-seven have approximate locality references; two ambiguous locations remain unmapped. Known occurrence dates must be within 28 May–28 October 2026. Reports with an unknown occurrence date may be displayed by publication date but cannot affect routes. No report is a supervised DNN target.

Nine records are eligible for the separate report-overlap comparison: they have a known in-window occurrence date, an explicit public-space relevance review, a resolved public map reference and uncertainty no larger than 2,000 metres. Residential, targeted/private, fraud, very broad or ambiguous reports remain context only. The eligible flag means usable for this comparison; it does not certify a crime or its continuing danger.

The backend tests each returned route polyline against eligible report areas. Fifty-metre samples estimate union overlap distance without double-counting overlapping circles. Among returned options taking at most 50% longer than the fastest, it suggests a lower-overlap route only when overlap falls by at least 100 metres. Otherwise it selects the fastest returned route and explains that the evidence does not establish a safety advantage. These thresholds are explicit interface heuristics, not learned or calibrated risk parameters. Nearby `lit=yes` and `lit=no` map observations are supporting context and do not determine the recommendation.

Hovering shows the reported issue, why the source supports that locality, event/publication dates, source link and location uncertainty. Reports sharing one locality coordinate are grouped so one marker cannot hide another. Each feed row also has a Locate on map button. Route cards compare each returned path directly with the fastest walk. A side-by-side table shows travel time, distance, report-area count, union overlap distance and mapped lit=yes observations. The explanation names report areas avoided, shared areas with reduced or increased overlap, and new areas entered by the alternative. Each area explanation links the dated source and states location uncertainty. A path that still enters an area is never described as avoiding it. Selecting another route updates its explanation, and a View suggested route button returns to the recommendation. Historical annual crime aggregates are excluded from the current application to honor the five-month requirement.

Official Digital Police states that searching crime/criminal data and reports is restricted to authorized police officers: [Digital Police](https://digitalpolice.gov.in/). No documented public live Delhi incident API with coordinates was verified in this research. Do not describe a live crime feed as connected until an authorized agreement and working endpoint exist.

A press-release issue date can describe an arrest or investigation long after the offense. Store occurrence time separately from publication time; leave an unknown date blank. Do not assign the investigating police station's coordinate to the crime scene. Do not fill Delhi neighborhoods with randomly allocated incidents from an annual city total.

For future authorized incidents, use this schema:

```json
{
  "event_id": "provider stable identifier",
  "source_id": "authorized provider identifier",
  "category": "official_incident",
  "observed_at": "ISO8601 with timezone",
  "published_at": "ISO8601 with timezone",
  "verified_at": "ISO8601 with timezone",
  "expires_at": "ISO8601 with timezone",
  "lat": "source-supported coordinate",
  "lon": "source-supported coordinate",
  "uncertainty_radius_m": "documented precision",
  "status": "pending or verified or disputed or revoked",
  "severity": "documented category scale",
  "verification_method": "source validation method"
}
```

`collectors/verified_incidents.py` validates a trusted input file, excludes pending/expired/revoked records, deduplicates event IDs and exports coarse aggregate locations. It does not authenticate an arbitrary file or establish that an occurrence is true. In production, authenticate providers, validate signatures, retain correction/retraction history and separate the private ingestion database from the public map projection.

## 5 Define the DNN target before training

Use a local-condition audit score as the initial supervised problem. Divide pedestrian streets into stable 50–150-metre segments, with identifiers that survive data refreshes. A record represents a segment and an observation time. Do not treat repeated rows from the same segment as independent samples.

Have two trained raters independently assess a segment at the observation time. Record five components on a documented 0–4 rubric. Example proposed weights are lighting 35%, activity 20%, usable transport access 20%, pedestrian infrastructure 15%, and verified report conditions 10%. These are design choices requiring stakeholder review, not established scientific constants.

```text
target_score = 25 × (0.35 L + 0.20 A + 0.20 T + 0.15 W + 0.10 R)
```

Write behavioral anchors for each rubric level. For lighting, distinguish continuously illuminated walking space from isolated lamps or mapped lamp presence. For activity, use observed open public-facing businesses and field counts rather than assumptions from shop tags. For transport, verify public entrance access and active service at the observation time. For walkway quality, record blocked paths and usable crossings. Report conditions must distinguish verified current warnings from absent reporting coverage.

If an audit component is unknown, do not silently award the maximum or renormalize to hide it. Keep the row unlabeled until the rubric's missing-label policy is resolved. Never derive the target from the same weighted input formula and then claim the ANN discovered a safety relationship; that experiment only reproduces a rule.

Compare inter-rater agreement before model training. Review systematic disagreements by time, segment type and geographic area. Record rater IDs privately, rubric version, adjudication and consent where relevant. The target measures this rubric, not crime probability, and should be named accordingly throughout the UI and report.

## 6 Features and preprocessing

The trainer expects eight condition inputs and three time features:

| Feature | Range in the training contract | Measurement meaning |
| --- | --- | --- |
| lighting | 0–1 | Independently measured/normalized illumination feature |
| open_businesses | 0–30 | Observed open-business count within the defined local buffer |
| transit_distance_m | 0–2,000 | Verified usable access distance, with documented clipping |
| footfall | 0–100 | Count using a fixed observation interval |
| verified_issue_load | 0–5 | Verified report burden under a frozen documented definition |
| sidewalk | 0–1 | Usable pedestrian-space measurement |
| crossing | 0–1 | Crossing-support measurement |
| outage_fraction | 0–1 | Confirmed affected lighting fraction |
| hour_sin and hour_cos | −1–1 | Cyclic local time encoding |
| weekend | 0 or 1 | Calendar feature in Asia/Kolkata |

Append eight missing-value masks for the eight condition inputs, producing 19 inputs. Blank means unavailable; zero means a measured zero. Compute medians, means and scales from the training partition only, then freeze them for validation, test and inference. Validate units and ranges at collection time, and preserve raw measurements before clipping or normalization.

Current OSM tags do not populate this complete training contract. For example, lit=yes is not measured illumination, and opening_hours without current observation is not verified open-business activity. These are separate proxy features or collection leads until audited. Do not infer protected demographic characteristics or stigmatize neighborhoods from community identity.

## 7 Model and training procedure

The included NumPy implementation uses `19 → 64 ReLU → 32 ReLU → 16 ReLU → 1 sigmoid`, with 3,905 parameters. Multiplying the sigmoid by 100 bounds the output. It uses MSE with L2 regularization, Adam at an initial learning rate of 0.001, mini-batches of 128 and validation-based early stopping with a maximum of 220 epochs. This is small enough for a normal CPU; no GPU is required for a first tabular project.

The learning pipeline is implemented, but there are currently no valid Delhi supervised targets to train it. Consequently, no real-model accuracy is claimed. Do not reuse the removed synthetic model's results in a project report.

Create geographic blocks larger than nearby correlated street segments. Place entire blocks in separate training, validation and test partitions. Require validation and test observations to occur after training, and test after validation. Keep a temporal gap matching the longest feature lookback and prevent later police verification or business status from leaking into earlier feature snapshots. The provided trainer enforces block disjointness and strict time order; its defaults do not by themselves implement a lookback embargo, which must be applied while constructing the CSV.

Suggested pilot collection is 300–600 distinct segments observed repeatedly across daytime, early evening and late evening over four to six weeks. This could produce several thousand audits, but it is not a guarantee of sufficient sample size. Check learning curves and coverage by geographic block. Scale toward citywide validity only after the initial data show stable holdout behavior.

Train a mean predictor and ridge regression alongside the DNN. A stronger tree baseline is a useful next experiment for tabular data. Adopt the DNN only if it improves useful held-out behavior. Save the model JSON, preprocessing, feature order, target/rubric version, training source hashes, data cutoffs, random seed, metrics and code revision. Activating an exported file in the production backend is a separate reviewed step.

## 8 Evaluation and explanations

Report MAE and RMSE in score points, held-out R², error by geography/time, performance with missing inputs, out-of-range detection and inter-rater agreement. Cluster bootstrap evaluation by independent street/area blocks rather than individual correlated rows. Show the test sample size and observation dates. No single accuracy percentage is sufficient for this regression task.

For risk bands, define the target and thresholds before looking at final test outcomes. Validate stability and interval coverage. Until then, high/medium/low labels have no defensible calibration. A true event-probability model would need representative incident observations, exposure denominators, reporting-delay handling and a different target/evaluation design. Annual counts plus selected news are inadequate for it.

The current explanation panel reports facts and gaps: lighting-tag observations, nearby facilities, rail access and overlapping approximate report areas. It explicitly states why these do not establish safe/unsafe status. Future model explanations can use grouped permutation importance and counterfactual feature sensitivity; describe these as model associations, not causal proof. Explanations must cite observed input facts and timestamps, not create narrative reasons from the score alone.

## 9 Routing and metro integration

Actual pedestrian geometry currently comes from Valhalla. The app requests one alternate; the provider may return fewer. Travel time is an estimate. Metro stations and tracks provide geographic context only: choosing a station as a walking endpoint does not create a metro journey.

After the indicator model is validated, expose a model-aware edge-cost engine on your own pedestrian graph. One proposed nonnegative cost is:

```text
cost(edge, time) = walk_minutes × [1 + λ(1 − indicator/100) + γ × missing_fraction]
```

All components must have compatible units. Close inaccessible edges using explicit source evidence. Score at expected arrival time where conditions vary; a static departure snapshot is a stated approximation. Return a fastest route, a balanced route and a higher-indicator candidate, deduplicate them and apply a user-visible detour budget. Several weighted shortest paths do not guarantee a globally optimal route under a hard detour constraint. Show walking distance, travel time, lowest segment indicator, missing-data distance and longest continuous weak-indicator section alongside averages.

True metro routing requires a graph of public station entrances, pathways, platform/line states and timed trips. Apply GTFS service calendars, date exceptions, trips, stop sequences, direction, frequencies, after-midnight times above 24:00, minimum transfers, first/last trains and closures. Charge initial wait, transfers and access walks explicitly. Treat metro interiors separately from the surface indicator; do not fabricate a value of 100 for train travel.

`collectors/import_gtfs.py` reads an authorized local zip and extracts scheduled arcs for inspection, including after-midnight times. It preserves calendar/frequency/transfer tables. Its median-arc export is not itself a timetable-aware journey planner and is not activated in the current app. OTD's portal archive must be checked against a current official DMRC network source before use.

## 10 Real updates and production architecture

Use scheduled or provider-driven ingestion, not model retraining after each event. Suggested architecture:

```text
Authorized source adapters → validated raw event store → moderation and deduplication
→ PostGIS segment/time joins → versioned feature snapshots → DNN batch inference
→ routing cache invalidation → route API → browser SSE or WebSocket updates
```

A practical production stack is FastAPI or a Node API, PostgreSQL/PostGIS, a queue/cache, independently scheduled collectors and a model registry. A frontend can use Leaflet as here, MapLibre, or the Google Maps JavaScript API with a properly restricted project key and billing. Google Maps is not required for the familiar street-map interaction in this implementation.

Choose update intervals from actual source contracts. Authorized bus feeds may refresh frequently; the interval must follow OTD's limits. Business opening-state checks run at local schedule boundaries with timezone/holiday support. Lighting observations need a source-specific expiry. Public map snapshots can refresh on an appropriate daily schedule. Stale evidence becomes missing, not safe. Show source observation time and last successful fetch separately from browser refresh time.

Handle idempotent provider IDs, duplicates, retries with backoff, clock skew, future timestamps, retractions, disputes, spatial uncertainty and source outages. An authorized report is not automatically still relevant hours later. Keep a bounded validity interval and preserve provenance for correction. Maintain incident-coverage metadata so absence of events is never equated with absence of crime.

The current shipped app is snapshot based. There is no saved automation, unattended collector, live incident source or live train source. Updating bundled data requires a server restart or hosted rebuild. The collector scripts are the starting point for a later ingestion service.

## 11 Delivery plan and acceptance checks

| Phase | Work | Acceptance evidence |
| --- | --- | --- |
| Actual-data foundation | Citywide map, provenance, real pedestrian routing, explicit unknown risk | Working map/API, source links, missing-data behavior |
| Audit pilot | Written rubric, repeated segment audits, independent raters | Quality checks and agreement report |
| Model study | Frozen features, geographic/time splits, baselines and DNN | Reproducible held-out metrics with no leakage |
| Model-aware routes | Segment graph, costs, detour and uncertainty handling | Controlled route comparisons and source-grounded explanations |
| Metro journeys | Current GTFS, entrances, calendars, transfers and last trains | Reference journey tests across service boundaries |
| Current incidents | Authorized source agreement and moderation workflow | Verified ingestion, expiry, correction and outage tests |
| Wider deployment | Hosting, source licensing, access controls and provider capacity | Monitoring, correction process and documented limits |

For an academic report, include problem definition, dataset provenance, audit methodology, feature dictionary, architecture, split construction, baseline comparison, held-out results, ablation/missingness analysis, route case studies and limits. Present data collection as part of the research contribution. Do not claim production crime prediction from the present snapshot application.

## 12 Source and service notes

OSM data require attribution and have ODbL obligations; retain the included attribution and review redistribution requirements for adapted databases. Leaflet's license is bundled under `public/vendor/leaflet/LICENSE`. Follow the [OSM tile policy](https://operations.osmfoundation.org/policies/tiles/): keep attribution visible, honor caching, do not bulk download tiles, and use a suitable provider for heavy production use.

[Valhalla's public-server documentation](https://valhalla.github.io/valhalla/start/introduction/) describes its fair-use service and client identification. The user explicitly approved sending two selected route coordinates for calculation. The application does not use device geolocation, collect personal criminal profiles, or send entire feature datasets with route requests.

[GTFS Realtime](https://developers.google.com/transit/gtfs-realtime) describes a format, not a guarantee that a particular agency publishes an accessible feed. Keep the distinction between data standard, authorized source access, and a working current integration visible in implementation and project claims.
