# Presentation guide

## Before presenting

1. Double-click `START_APP.cmd` and keep its terminal open.
2. Open http://127.0.0.1:8787/ in a browser.
3. Check the internet connection for map tiles and routing. A reference screenshot is in `screenshots/dashboard.png`.

## Suggested five-minute demonstration

1. **Problem:** compare walking routes using available local evidence, and explain the choice.
2. **Map:** show Delhi coverage, the metro overlay and dated report markers. Hover a marker and open its source.
3. **Routes:** choose Ramakrishna Ashram Marg and Karol Bagh, then compare walking routes. Use the current returned figures rather than promising a fixed travel time.
4. **Reasoning:** highlight the prominent reason panel. Explain report-area overlap, walking time, areas avoided or still entered, and source uncertainty. Switch routes to show the comparison updating.
5. **ANN:** open `ml/train.py` and explain the 19 → 64 → 32 → 16 → 1 network. Describe training-only preprocessing, missing-value masks, Adam, early stopping, spatial/temporal splits and baseline comparison.

## Architecture

```text
Actual OSM + reviewed reports
          ↓
Normalized datasets in data/
          ↓
Node API + Valhalla walking routes
          ↓
Report-area overlap comparison
          ↓
Interactive map + source-linked explanations

Independent field audits → NumPy DNN training → held-out evaluation
```

## What to say accurately

- The map and routing application work with actual source data.
- The report snapshot covers the last-five-month window shown in the app; it is selected coverage, not a complete crime census.
- A suggested path has a documented tradeoff in mapped-report overlap and travel time. This is not proof that it is safe.
- Training code is implemented. A validated Delhi risk model and live police feed have not been obtained, so risk inference is disabled.
- Metro geometry is available; live trains and scheduled metro journey planning are future work.

## Files worth showing

| Topic | File |
| --- | --- |
| Interface | `public/map.html`, `public/explorer.css` |
| Route evidence | `src/route-evidence.mjs` |
| API | `src/real-api.mjs` |
| DNN | `ml/train.py` |
| Dataset and source links | `data/reported_incidents.csv` |
| Audit schema | `data/audit_template.csv` |
| Detailed methodology | `docs/PROJECT_GUIDE.md` |

The data collectors and original source snapshots are retained for reproducibility. Installed framework packages, unused starter code, build caches and repeated exports are unnecessary for this local demo and have been removed.
