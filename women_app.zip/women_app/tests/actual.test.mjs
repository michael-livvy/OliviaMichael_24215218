import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {api} from '../src/real-api.mjs';
import {route,validatePoint,decodePolyline} from '../src/routing.mjs';
import data from '../data/actual_features.json' with {type:'json'};
import {evaluateRoutes} from '../src/route-evidence.mjs';
test('actual data has source provenance and no fabricated scores',()=>{
 assert.equal(data.data_origin,'actual_openstreetmap');assert.ok(data.features.length>1000);
 assert.equal(data.features.length,Object.values(data.counts).reduce((a,b)=>a+b,0));
 assert.ok(data.features.every(f=>f.website.startsWith('https://www.openstreetmap.org/')));
 assert.ok(data.features.every(f=>f.score===undefined&&Number.isFinite(f.lat)&&Number.isFinite(f.lon)));
});
test('actual API exposes unknown risk and disables untrained predictions',async()=>{
 const health=await(await api(new Request('https://app.test/api/health'))).json();assert.equal(health.mode,'actual_data_only');
 const model=await(await api(new Request('https://app.test/api/model'))).json();assert.equal(model.predictions_enabled,false);
 const prediction=await api(new Request('https://app.test/api/predict'));assert.equal(prediction.status,503);
 const network=await(await api(new Request('https://app.test/api/network'))).json();assert.equal(network.risk_status,'unknown');assert.equal(network.live_crime_status,'not_connected');
});
test('published reports have sources, event/publication dates and coarse precision',async()=>{
 const x=await(await api(new Request('https://app.test/api/incidents'))).json();assert.ok(x.records.every(r=>r.risk_label===null));
 assert.ok(x.records.length>3);assert.deepEqual(x.window.start,'2026-05-28');assert.equal(x.window.end,'2026-10-28');
 assert.ok(x.records.every(r=>r.source_url.startsWith('https://')&&r.report_date&&(r.lat===null||r.uncertainty_radius_m>=500)));
 assert.ok(x.records.every(r=>r.report_date>=x.window.start&&r.report_date<=x.window.end));
 assert.ok(x.records.every(r=>!r.event_date||(r.event_date>=x.window.start&&r.event_date<=x.window.end)));
 assert.ok(x.records.filter(r=>r.routing_eligible).every(r=>r.event_date&&r.uncertainty_radius_m<=2000));
});
test('route coordinates are bounded and malformed input is rejected',async()=>{
 assert.throws(()=>validatePoint({lat:Infinity,lon:77}));assert.throws(()=>validatePoint({lat:0,lon:0}));
 assert.throws(()=>decodePolyline('_'));
 const invalid=await api(new Request('https://app.test/api/routes',{method:'POST',body:'bad'}));assert.equal(invalid.status,400);
 const big=await api(new Request('https://app.test/api/routes',{method:'POST',body:'x'.repeat(9000)}));assert.equal(big.status,413);
});
test('routing sends only the approved two pins and pedestrian options; outputs no risk score',async()=>{
 let called=0;const from={lat:28.6328,lon:77.2197},to={lat:28.6234,lon:77.2146};
 const mock=async(url,opts)=>{called++;assert.equal(new URL(url).hostname,'valhalla1.openstreetmap.de');const payload=JSON.parse(new URL(url).searchParams.get('json'));
  assert.deepEqual(payload.locations,[from,to]);assert.equal(payload.costing,'pedestrian');assert.ok(opts.headers['X-Client-Id']);
  return new Response(JSON.stringify({trip:{summary:{time:600,length:1},legs:[{shape:'??',maneuvers:[{instruction:'Walk',time:600,length:1}]}]}}),{status:200});};
 const out=await route({from,to},mock);assert.equal(out.routes[0].minutes,10);assert.equal(out.routes[0].score,null);assert.deepEqual(out.routes[0].geometry,[[0,0]]);
 await route({from,to},mock);assert.equal(called,1);
});
test('provider failure never substitutes a fabricated route',async()=>{
 await assert.rejects(route({from:{lat:28.64,lon:77.22},to:{lat:28.60,lon:77.20}},async()=>new Response('down',{status:503})),/unavailable/);
});
test('map module parses and contains no active synthetic pipeline',()=>{
 const html=readFileSync(new URL('../public/map.html',import.meta.url),'utf8');const code=html.match(/<script type="module">([\s\S]*?)<\/script>/)[1];new vm.Script(`(async()=>{${code}\n})`);
 assert.ok(html.includes('Actual sources'));assert.ok(!html.includes('scenario='));assert.ok(html.includes('explainArea'));assert.ok(html.includes('group.map(reportHtml)'));assert.ok(html.includes('.bindTooltip(html'));
});
test('route comparison excludes unknown dates and irrelevant reports; explains a bounded lower-overlap option',()=>{
 const routes=[{id:'a',minutes:10,geometry:[[28.6,77.2],[28.61,77.2]]},{id:'b',minutes:12,geometry:[[28.6,77.22],[28.61,77.22]]}];
 const reports=[{id:'known',lat:28.605,lon:77.2,event_date:'2026-10-10',routing_eligible:true,uncertainty_radius_m:300},
 {id:'unknown',lat:28.605,lon:77.22,event_date:null,routing_eligible:false,uncertainty_radius_m:300},
 {id:'old',lat:28.605,lon:77.22,event_date:'2026-01-01',routing_eligible:true,uncertainty_radius_m:300}];
 const out=evaluateRoutes(routes,[],reports,Date.parse('2026-10-28'));assert.equal(out.routes[0].evidence.report_count,1);assert.equal(out.routes[1].evidence.report_count,0);
 assert.equal(out.recommendation.id,'b');assert.equal(out.recommendation.safety_status,'not_validated');assert.ok(out.recommendation.reason.includes('less overlap'));
 assert.equal(out.recommendation.baseline_id,'a');assert.deepEqual(out.routes[1].comparison.avoided_report_ids,['known']);assert.equal(out.routes[1].comparison.extra_minutes,2);
 const excessive=evaluateRoutes([routes[0],{...routes[1],minutes:20}],[],reports,Date.parse('2026-10-28'));assert.equal(excessive.recommendation.id,'a');
});
test('shared report areas are described as reduced overlap, not as avoided',()=>{
 const routes=[{id:'fast',minutes:10,length_m:1100,geometry:[[28.6,77.2],[28.61,77.2]]},{id:'alt',minutes:11,length_m:1100,geometry:[[28.6,77.202],[28.61,77.202]]}];
 const report={id:'shared',area:'Reviewed locality',lat:28.605,lon:77.2,event_date:'2026-10-10',routing_eligible:true,uncertainty_radius_m:300};
 const out=evaluateRoutes(routes,[],[report],Date.parse('2026-10-28'));
 assert.equal(out.recommendation.id,'alt');assert.equal(out.routes[1].evidence.report_count,1);
 assert.deepEqual(out.routes[1].comparison.avoided_report_ids,[]);assert.equal(out.routes[1].comparison.reduced_report_areas[0].id,'shared');
 assert.ok(out.routes[1].comparison.reduced_report_areas[0].route_overlap_m>0);
});
test('comparison exposes newly entered areas and handles a single returned route honestly',()=>{
 const routes=[{id:'fast',minutes:10,length_m:1100,geometry:[[28.6,77.2],[28.61,77.2]]},{id:'alt',minutes:11,length_m:1100,geometry:[[28.6,77.22],[28.61,77.22]]}];
 const base={event_date:'2026-10-10',routing_eligible:true,lat:28.605};
 const reports=[{...base,id:'old-path',area:'First area',lon:77.2,uncertainty_radius_m:400},{...base,id:'new-path',area:'Second area',lon:77.22,uncertainty_radius_m:150}];
 const out=evaluateRoutes(routes,[],reports,Date.parse('2026-10-28'));
 assert.equal(out.recommendation.id,'alt');assert.deepEqual(out.routes[1].comparison.added_report_ids,['new-path']);assert.ok(out.recommendation.reason.includes('Second area'));
 const single=evaluateRoutes([routes[0]],[],reports,Date.parse('2026-10-28'));assert.equal(single.recommendation.meaningful_reduction,false);assert.match(single.recommendation.reason,/Only one/);
});
test('police releases are within five months and station locations are never presented as scenes',async()=>{
 const context=await(await api(new Request('https://app.test/api/crime-context'))).json();assert.equal(context.annual,undefined);
 assert.ok(context.police_releases.records.length>0);
 assert.ok(context.police_releases.records.every(r=>r.incident_location===null&&r.published_at>=context.window.start&&r.published_at<=context.window.end));
});
