# Dataset inventory

| File | Role |
| --- | --- |
| `actual_features.json` | Runtime OSM observations, source metadata and metro geometries |
| `reported_incidents.json` | Runtime reviewed reports, location uncertainty and route eligibility |
| `police_releases.json` | Runtime official release metadata; investigating stations are not incident coordinates |
| `actual_features.csv`, `reported_incidents.csv` | Tabular exports for inspection and presentation |
| `audit_template.csv` | Empty schema for collecting independent real training labels |
| `delhi_actual.json` | Raw NCT Delhi OSM query response and provenance |
| `place_index.json` | Actual public place/road references used to review locality anchors |
| `osm_small_delhi.osm`, `osm_small_delhi.json` | Original central-Delhi sample and metadata for reproducibility |

The runtime report window is 28 May–28 October 2026. There are 29 source-reviewed public reports, 27 mapped references and 9 records eligible for report-overlap comparison. Sources are linked in each record. Unknown event dates, unresolved locations and excluded context reports do not influence the route recommendation.

The OSM snapshot was fetched on 27 October 2026. Feature counts describe mapped objects rather than verified operating facilities. Metro geometries are mapped tracks, not a live timetable.

News reports are not supervised DNN labels. Training requires independently audited observations with the documented target rubric, explicit spatial blocks and chronological splits. No synthetic labels or trained synthetic weights are included.
