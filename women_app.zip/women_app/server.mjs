// Lightweight local server: same backend and DNN as the hosted Vinext adapter.
// Node 22.13+; no npm packages required for this local path.
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {api} from './src/real-api.mjs';
const port=Number(process.env.PORT??8787);
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,`http://127.0.0.1:${port}`);
  if(url.pathname.startsWith('/api/')){
   const chunks=[];let size=0;
   for await(const chunk of req){size+=chunk.length;if(size>8192){res.writeHead(413);res.end('Request too large');return;}chunks.push(chunk);}
   const request=new Request(url,{method:req.method,headers:req.headers,...(req.method==='POST'?{body:Buffer.concat(chunks)}:{})});
   const response=await api(request);res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
  }else if(url.pathname==='/'||url.pathname==='/index.html'){
   res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});res.end(await readFile(new URL('./public/map.html',import.meta.url)));
  }else if(['/vendor/leaflet/leaflet.js','/vendor/leaflet/leaflet.css','/explorer.css'].includes(url.pathname)){
   res.writeHead(200,{'content-type':url.pathname.endsWith('.css')?'text/css':'text/javascript','cache-control':url.pathname==='/explorer.css'?'no-store':'public, max-age=86400'});
   res.end(await readFile(new URL('./public'+url.pathname,import.meta.url)));
  }else{res.writeHead(404);res.end('Not found');}
 }catch(e){res.writeHead(500);res.end('Server error');console.error(e.message);}
});
server.listen(port,'127.0.0.1',()=>console.log(`Delhi Route Lab: http://127.0.0.1:${port}`));
